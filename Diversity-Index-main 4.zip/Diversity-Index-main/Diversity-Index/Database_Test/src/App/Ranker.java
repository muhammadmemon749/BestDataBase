/**
 * The class Ranker ranks the companies based on various metrics and stores these rankings in separate ArrayLists.
 * @author Faith Tong
 */

package App;

import java.util.ArrayList;
import Comparators.*;
import DataBase.DatabaseAccess;

public class Ranker {
    ArrayList<DatabaseAccess> companies;
    ArrayList<DatabaseAccess> genderRanking;
    ArrayList<DatabaseAccess> diversityRanking;
    ArrayList<DatabaseAccess> safetyRanking;
    ArrayList<DatabaseAccess> overallRanking;

    /**
     * Creates a Ranker object with a separate ArrayList for each ranking.
     * @param companies ArrayList of companies to be ranked.
     */
    Ranker(ArrayList<DatabaseAccess> companies) {
        this.companies = companies;
        genderRanking = new ArrayList<DatabaseAccess>(companies);
        diversityRanking = new ArrayList<DatabaseAccess>(companies);
        safetyRanking = new ArrayList<DatabaseAccess>(companies);
        overallRanking = new ArrayList<DatabaseAccess>(companies);
    }

    /**
     * Takes the given companies and sorts each ArrayList based on custom metric Comparators.
     */
    void rankCompanies() {
        genderRanking.sort(new GenderComparator());
        diversityRanking.sort(new DiversityComparator());
        safetyRanking.sort(new SafetyComparator());
        overallRanking.sort(new OverallComparator(genderRanking, diversityRanking, safetyRanking));
    }

    /**
     * Returns the ArrayList storing the overall ranking of companies.
     * @return ArrayList<DatabaseAccess> overallRanking storing the overall ranking.
     */
    public ArrayList<DatabaseAccess> getOverallRanking() {
        return overallRanking;
    }

    /**
     * Returns the ArrayList storing the diversity ranking of companies.
     * @return ArrayList<DatabaseAccess> diversityRanking storing the overall ranking.
     */
    public ArrayList<DatabaseAccess> getDiversityRanking() {
        return diversityRanking;
    }

    /**
     * Returns the ArrayList storing the gender ranking of companies.
     * @return ArrayList<DatabaseAccess> genderRanking storing the overall ranking.
     */
    public ArrayList<DatabaseAccess> getGenderRanking() {
        return genderRanking;
    }

    /**
     * Returns the ArrayList storing the safety ranking of companies.
     * @return ArrayList<DatabaseAccess> safetyRanking storing the overall ranking.
     */
    public ArrayList<DatabaseAccess> getSafetyRanking() {
        return safetyRanking;
    }

}