package GUI;

import javax.swing.*;

public class ReviewPage {

    public static void createFrame() {
        JFrame frame = new JFrame("Review Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }


}
