package DataBase;

import java.sql.*;
import java.io.*;
import java.util.Scanner;

public class CompanyTableManager {
    private Connection con;

    public CompanyTableManager(Connection con) {
        this.con = con;
    }

    public void createTable() throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS CompanyDetails (" +
                                "company_name VARCHAR(255), " +
                                "company_overview VARCHAR(255), " +
                                "percent_of_minorities_hired INT, " +
                                "percent_females_hired INT, " +
                                "percent_males_hired INT, " +
                                "workplace_safety_score INT)";
        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(createTableSQL);
            System.out.println("Table 'CompanyDetails' is created successfully.");
        }
    }

    public void insertDataFromFile(String filePath) throws SQLException, FileNotFoundException {
        File file = new File(filePath);
        try (Scanner scanner = new Scanner(file);
             PreparedStatement pstmt = con.prepareStatement(
                "INSERT INTO CompanyDetails (company_name, company_overview, percent_of_minorities_hired, " +
                "percent_females_hired, percent_males_hired, workplace_safety_score) VALUES (?, ?, ?, ?, ?, ?)")) {
            
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] values = line.split(", ");
                for (int i = 0; i < values.length; i++) {
                    pstmt.setString(i + 1, values[i].trim());
                }
                pstmt.executeUpdate();
            }
            System.out.println("Data from file inserted successfully.");
        }
    }
}



            // Insert data from the file
            //insertDataFromFile("/Users/muhammadmemon/Downloads/companies_data.txt");
