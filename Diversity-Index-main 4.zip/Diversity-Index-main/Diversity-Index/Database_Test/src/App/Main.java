package App;

import java.util.ArrayList;
import javax.swing.*;
import GUI.*;
import DataBase.CompanyTableManager;
import DataBase.DataBaseConnection;
import DataBase.DatabaseAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {


    public static void main(String[] args) {

        try {
            // Establishing connection to the database
            Connection con = DataBaseConnection.getConnection();

            // Managing company table
            CompanyTableManager tableManager = new CompanyTableManager(con);
            tableManager.createTable();
            tableManager.insertDataFromFile("/Users/muhammadmemon/Downloads/companies_data.txt");


        } catch (Exception e) {
            e.printStackTrace();
        }
    
        //Faith
        if (rs != null) {
            ArrayList<DatabaseAccess> companies = new ArrayList<>();

            try {
                while (rs.next()) {
                    DatabaseAccess company = DatabaseAccess.fromResultSet(rs);
                    companies.add(company);
                }
            } catch (SQLException s) {
                System.out.println(s);
            }

            Ranker ranker = new Ranker(companies);
            ranker.rankCompanies();

            //Yazan
            SwingUtilities.invokeLater(() -> CompanyPage.createFrame());
            SwingUtilities.invokeLater(() -> CompanyPage.createRankingGUI());
            SwingUtilities.invokeLater(() -> StartingPage.createAndShowGUI(companies, ranker));
        }

        
        
    }
}
