package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DataRetrieval {
    private Connection con;

    public DataRetrieval(Connection con) {
        this.con = con;
    }

    /**
     * Retrieves all company details from the database and converts them to CompanyDetails objects.
     * 
     * @return A list of CompanyDetails objects.
     * @throws SQLException if a database access error occurs or the SQL statement is not valid.
     */
    public List<DatabaseAccess> getCompanyDetails() throws SQLException {
        List<DatabaseAccess> companyList = new ArrayList<>();
        String query = "SELECT * FROM CompanyDetails";

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                String companyName = rs.getString("company_name");
                String companyOverview = rs.getString("company_overview");
                int percentOfMinoritiesHired = rs.getInt("percent_of_minorities_hired");
                int percentFemalesHired = rs.getInt("percent_females_hired");
                int percentMalesHired = rs.getInt("percent_males_hired");
                int workplaceSafetyScore = rs.getInt("workplace_safety_score");

                DatabaseAccess companyDetails = new DatabaseAccess(companyName, companyOverview, 
                                                                   percentOfMinoritiesHired, percentFemalesHired, 
                                                                   percentMalesHired, workplaceSafetyScore);
                companyList.add(companyDetails);
            }
        }

        return companyList;
    }
}
