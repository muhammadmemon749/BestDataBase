package DataBase;

import java.sql.ResultSet;

/**
 * Represents a single record in the CompanyDetails table.
 */
public class DatabaseAccess {
    private String companyName;
    private String companyOverview;
    private int percentOfMinoritiesHired;
    private int percentFemalesHired;
    private int percentMalesHired;
    private int workplaceSafetyScore;

    // Constructor
    public DatabaseAccess(String companyName, String companyOverview, int percentOfMinoritiesHired, int percentFemalesHired, int percentMalesHired, int workplaceSafetyScore) {
        this.companyName = companyName;
        this.companyOverview = companyOverview;
        this.percentOfMinoritiesHired = percentOfMinoritiesHired;
        this.percentFemalesHired = percentFemalesHired;
        this.percentMalesHired = percentMalesHired;
        this.workplaceSafetyScore = workplaceSafetyScore;
    }

    // Getters and Setters
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyOverview() {
        return companyOverview;
    }

    public void setCompanyOverview(String companyOverview) {
        this.companyOverview = companyOverview;
    }

    public int getPercentOfMinoritiesHired() {
        return percentOfMinoritiesHired;
    }

    public void setPercentOfMinoritiesHired(int percentOfMinoritiesHired) {
        this.percentOfMinoritiesHired = percentOfMinoritiesHired;
    }

    public int getPercentFemalesHired() {
        return percentFemalesHired;
    }

    public void setPercentFemalesHired(int percentFemalesHired) {
        this.percentFemalesHired = percentFemalesHired;
    }

    public int getPercentMalesHired() {
        return percentMalesHired;
    }

    public void setPercentMalesHired(int percentMalesHired) {
        this.percentMalesHired = percentMalesHired;
    }

    public int getWorkplaceSafetyScore() {
        return workplaceSafetyScore;
    }

    public void setWorkplaceSafetyScore(int workplaceSafetyScore) {
        this.workplaceSafetyScore = workplaceSafetyScore;
    }

}
