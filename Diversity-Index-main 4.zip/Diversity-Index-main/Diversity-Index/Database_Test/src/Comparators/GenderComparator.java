/**
 * GenderComparator implements the Comparator interface and can compare DatabaseAccess objects based on the ratio of males to females they hire.
 * @author Faith Tong
 */

package Comparators;

import java.util.Comparator;
import java.lang.Math;
import DataBase.DatabaseAccess;

public class GenderComparator implements Comparator<DatabaseAccess> {
    /**
     * Compares companies by seeing how similar the percentages of genders hired the company has.
     * @param d1 DatabaseAccess object which is being compared to another company.
     * @param d2 The second DatabaseAccess object being compared.
     * @return Returns an integer. -1 if d1 comes before d2, 0 if they are the same, 1 if c1 comes after d2.
     */
    public int compare(DatabaseAccess d1, DatabaseAccess d2) {
        double d1Difference = Math.abs(d1.getPercentMalesHired() - d1.getPercentFemalesHired());
        double d2Difference = Math.abs(d2.getPercentMalesHired() - d2.getPercentFemalesHired());

        if (d1Difference < d2Difference) {
            return -1;
        }
        else if (d1Difference == d2Difference) {
            return 0;
        }
        else {
            return 1;
        }
    }
}
